--Anything without an "equal sign" is skipped, this parsing awill be changed later probably

WIDTH = .76f
HEIGHT = 1.28f

DENSITY = 1f

WALK_SPEED = 200f
MAX_SPEED = 8f
STOP_FRICTION = 5f

JUMP_START_IMPULSE = 12f
JUMP_HOLD_IMPULSE = 2.2f
JUMP_HOLD_TIME = .15f

KICKOFF_START_IMPULSE = 40f