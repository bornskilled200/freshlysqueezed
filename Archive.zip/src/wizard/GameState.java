package wizard;

/**
 * Created with IntelliJ IDEA.
 * User: David Park
 * Date: 3/24/13
 * Time: 12:43 PM
 * To change this template use File | Settings | File Templates.
 */
public enum GameState {
    PAUSED, RUNNING;
}
