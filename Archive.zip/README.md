freshlysqueezed
===============
If you want to compile this project, you will need LibGDX and LuaJ(If you want LuaLevel.java and DataLoader.java to work). 

<p>For LibGDX, I recommend you to install <a href="http://libgdx.badlogicgames.com/nightlies/libgdx-nightly-latest.zip">the latest nightly</a> or <a href="https://code.google.com/p/libgdx/downloads/list">the latest version</a>. I use version 0.9.8.</p>
<p>For LuaJ, you can find it <a href="http://sourceforge.net/projects/luaj/">here</a>.</p>
